import React from 'react';
import Login from './Login';

const LoginWindow = () => {
  return (
    <div style={{ margin: 0, padding: 0 }}>
      <Login />
    </div>
  );
};

export default LoginWindow;
