import React from 'react'


const Map = () => {
  return (
    <>
      <img src="https://mblogthumb-phinf.pstatic.net/20140722_248/brigade3_1406031923172C7KiU_PNG/%C4%B8%C3%B30.PNG?type=w420" alt="" />
    </>
  )
}

export default Map;