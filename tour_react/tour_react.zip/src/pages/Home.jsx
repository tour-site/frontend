// 📁 src/pages/Home.jsx
import { useState } from "react";
import BusanMap from "../components/BusanMapSvg";

function Home() {
  const [selectedGu, setSelectedGu] = useState(null);

  return (
    <div style={{ padding: "2rem" }}>
      <h2>부산 지역 여행 지도</h2>
      <BusanMap onGuClick={(id) => setSelectedGu(id)} />

      {selectedGu && (
        <div style={{ marginTop: "2rem" }}>
          <h3>{selectedGu} 선택됨</h3>
        </div>
      )}
    </div>
  );
}

export default Home;
