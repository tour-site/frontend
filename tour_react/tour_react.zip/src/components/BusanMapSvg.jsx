// 📁 src/components/BusanMapSvg.jsx
import BusanSvg from "../assets/Busan_districts.svg?component";

function BusanMap({ onGuClick }) {
  return (
    <div style={{ width: "100%", maxWidth: "800px", margin: "0 auto" }}>
      <BusanSvg
        style={{ width: "100%", height: "auto" }}
        onClick={(e) => {
          const guName = e.target.getAttribute("id");
          if (guName) {
            onGuClick(guName);
          }
        }}
      />
    </div>
  );
}

export default BusanMap;
