// 📁 src/pages/Mypage.jsx
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axiosInstance.js'; // ✅ 우리가 만든 axios 인스턴스 사용

function Mypage() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const logout = () => {
    // ❌ 더 이상 localStorage 사용 안 함
    // 서버에 로그아웃 요청하거나 쿠키 삭제는 백엔드에서 담당 가능
    navigate('/');
  };

  useEffect(() => {
    axios
      .get('/api/member/me') // ✅ 쿠키로 자동 인증
      .then((res) => setUser(res.data))
      .catch((err) => {
        console.error(err);
        alert('로그인 정보가 없거나 세션이 만료되었습니다.');
        logout();
      });
  }, []);

  return (
    <div>
      <h2>마이페이지</h2>
      {user ? (
        <pre>{JSON.stringify(user, null, 2)}</pre>
      ) : (
        <p>불러오는 중...</p>
      )}
      <button onClick={logout}>로그아웃</button>
    </div>
  );
}

export default Mypage;
